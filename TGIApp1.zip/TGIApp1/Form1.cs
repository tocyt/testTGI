using System.Data;
using System.Xml.Linq;

namespace TGIApp1
{
    public partial class Form1 : Form
    {
        DataTable dtCustomer = new DataTable("Customer");
        int index;
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            dtCustomer.Columns.Add("ID", Type.GetType("System.Int32"));
            dtCustomer.Columns.Add("name", Type.GetType("System.String"));
            dtCustomer.Columns.Add("age", Type.GetType("System.Int32"));
            dtCustomer.Columns.Add("postcode", Type.GetType("System.String"));
            dtCustomer.Columns.Add("height", Type.GetType("System.Decimal"));

            dataGridView1.DataSource = dtCustomer;
        }


        /// <summary>
        /// Insert customer data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.Clear();

                int errorFlag = 0;
                if (string.IsNullOrEmpty(txtId.Text.Trim()))
                {
                    errorProvider1.SetError(txtId, "ID is required.");
                    errorFlag=1;
                }
                if (string.IsNullOrEmpty(txtName.Text.Trim()))
                {
                    errorProvider1.SetError(txtName, "Name is required.");
                    errorFlag = 1;
                }
                if (string.IsNullOrEmpty(txtAge.Text.Trim()))
                {
                    errorProvider1.SetError(txtAge, "Age is required.");
                    errorFlag = 1;
                }
                if (string.IsNullOrEmpty(txtPostCode.Text.Trim()))
                {
                    errorProvider1.SetError(txtPostCode, "Post code is required.");
                    errorFlag = 1;
                }
                if (string.IsNullOrEmpty(txtHeight.Text.Trim()))
                {
                    errorProvider1.SetError(txtHeight, "Height is required.");
                    errorFlag = 1;
                }
                if (Convert.ToInt32(txtAge.Text) < 0 || Convert.ToInt32(txtAge.Text) > 110)
                {
                    errorProvider1.SetError(txtAge, "Age should be between 0 to 110.");
                    errorFlag = 1;
                }

                if (errorFlag == 0)
                {
                    dtCustomer.Rows.Add(Convert.ToInt32(txtId.Text), txtName.Text.ToString(), Convert.ToInt32(txtAge.Text), txtPostCode.Text.ToString(), Convert.ToDecimal(txtHeight.Text));

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred in insert customer.{0}",ex.InnerException.ToString());
            }
        }

        /// <summary>
        /// Clear fields to add new details
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                txtId.Text = string.Empty;
                txtName.Text = string.Empty;
                txtAge.Text = string.Empty;
                txtPostCode.Text = string.Empty;
                txtHeight.Text = string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred in add new customer..{0}",ex.InnerException.ToString());
            }
        }

        /// <summary>
        /// Delete customer data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if  (txtId.Text==null )
                {
                    MessageBox.Show("Please select a record to delete!");
                    
                }
                if ((Convert.ToInt32(txtId.Text) <= 0))
                {
                    MessageBox.Show("Customer id should not be zero!");

                }
                if ((Convert.ToInt32(txtId.Text) > 0))
                {
                    index = dataGridView1.CurrentCell.RowIndex;
                    dataGridView1.Rows.RemoveAt(index);

                    txtId.Text = string.Empty;
                    txtName.Text = string.Empty;
                    txtAge.Text = string.Empty;
                    txtPostCode.Text = string.Empty;
                    txtHeight.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred in delete customer.");
            }
        }

        /// <summary>
        /// Update customer data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.Rows[index].Cells[0].Value.ToString() == null)
                {
                    MessageBox.Show("Please select a record to update!");
                }
                else if (txtId.Text == dataGridView1.Rows[index].Cells[0].Value.ToString())
                {
                    // dataGridView1.Rows[index].Cells[0].Value = txtId.Text;
                    dataGridView1.Rows[index].Cells[1].Value = txtName.Text;
                    dataGridView1.Rows[index].Cells[2].Value = txtAge.Text;
                    dataGridView1.Rows[index].Cells[3].Value = txtPostCode.Text;
                    dataGridView1.Rows[index].Cells[4].Value = txtHeight.Text;
                }
                else
                {
                    MessageBox.Show("Record not exists.");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred in Add customer.");
            }
        }

        /// <summary>
        /// Select row from grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                index = e.RowIndex;

                txtId.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtName.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtAge.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                txtPostCode.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                txtHeight.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();

            }
            catch(Exception ex)
            {
                MessageBox.Show("Error occurred in selection.");
            }
        }

        private void txtPostCode_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
           
        }
    }
}